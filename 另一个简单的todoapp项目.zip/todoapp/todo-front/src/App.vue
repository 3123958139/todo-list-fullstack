<script setup>
import TodoList from './components/TodoList.vue';
</script>

<template>
  <div id="app">
    <el-container>
      <el-main>
        <TodoList/>
      </el-main>
    </el-container>
  </div>
</template>
